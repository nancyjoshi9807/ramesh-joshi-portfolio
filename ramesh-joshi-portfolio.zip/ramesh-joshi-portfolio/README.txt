RAMESH JOSHI — PORTFOLIO WEBSITE

FILES
- index.html: website content
- style.css: design and responsive layout
- script.js: mobile navigation
- assets/profile.png: supplied professional portrait

BEFORE PUBLISHING
1. Open index.html and replace your-email@example.com with your real email address.
2. Check that the job title, company name and listed responsibilities accurately describe your work.
3. Add your LinkedIn or other professional profile link if you want one.

PUBLISH WITH GITHUB PAGES
1. Sign in to GitHub and create a new public repository, for example: ramesh-joshi-portfolio.
2. Upload all files and the assets folder, keeping the same folder structure.
3. Open the repository's Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder / (root), then Save.
6. After GitHub finishes publishing, your site address will appear on the Pages settings screen.
